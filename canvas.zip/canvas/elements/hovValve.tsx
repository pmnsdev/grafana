import { css } from '@emotion/css';
import { v4 as uuidv4 } from 'uuid';

import { GrafanaTheme2, OneClickMode } from '@grafana/data';
import { config } from 'app/core/config';
import { DimensionContext } from 'app/features/dimensions';
import { ColorDimensionEditor } from 'app/features/dimensions/editors/ColorDimensionEditor';
import { TextDimensionEditor } from 'app/features/dimensions/editors/TextDimensionEditor';

import {
  CanvasElementItem,
  CanvasElementProps,
  CanvasElementOptions,
  defaultBgColor,
  defaultTextColor,
} from '../element';
import { Align, CanvasElementConfig, CanvasElementData, VAlign } from '../types';

const Valvehov = (props: CanvasElementProps<CanvasElementConfig, CanvasElementData>) => {
  const { data } = props;
  const styles = getStyles(config.theme2, data);

  // uuid needed to avoid id conflicts when multiple elements are rendered
  const uniqueId = uuidv4();

  return (
    <div className={styles.container}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 493 454"        
        width="100%"
        height="100%"
        preserveAspectRatio="none"
      >
        <g>
          <path
            d="M 5 230 L 235 335 L 5 440 Z"
            style={{ fill: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
            strokeWidth="10"
          />

          <path
            d="M 258 230 L 488 335 L 258 440 Z"
            style={{ fill: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
            strokeWidth="10"
            transform="rotate(-180,373,335)"
          />

          <ellipse
            cx="246"
            cy="342"
            rx="90"
            ry="90"
            style={{ fill: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
          />
          <rect
            x="184"
            y="27"
            width="125"
            height="125"
            fill="none"
            strokeWidth="5"
            style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
          />

          <text
            x="246"
            y="135"
            fontFamily="Ubuntu Sans"
            fontSize="150"
            textAnchor="middle"
            fontWeight="bold"
            stroke = {data?.backgroundImage}
            style={{fill: data?.backgroundImage ?  `url(#image-${uniqueId})` : data?.backgroundColor }}
          >
            H
          </text>
          <path
            d="M 246.5 152 L 246.5 252"
            style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
            stroke-width="5"
          />
          <path
            d="M 367.5 188.5 L 430.5 188.5"
            style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
            strokeWidth={5}
            strokeMiterlimit={10}
            transform="rotate(90,399,188.5)"
            pointerEvents="all"
          />
          <path
              d="M 399 188.5 L 247 188"
              style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
              strokeWidth={5}
              strokeMiterlimit={10}
              pointerEvents="stroke"
            />
            </g>
      </svg>
      <span className={styles.text}>{data?.text}</span>
    </div>
  );
};

export const valvehovItem: CanvasElementItem = {
  id: 'valvehov',
  name: 'Valve Hov',
  description: 'Valve Hov',

  display: Valvehov,

  defaultSize: {
    width: 110,
    height: 70,
  },

  getNewOptions: (options) => ({
    ...options,
    background: {
      color: {
        fixed: defaultBgColor,
      },
    },
    config: {
      align: Align.Center,
      valign: VAlign.Middle,
      color: {
        fixed: defaultTextColor,
      },
    },
    placement: {
      width: options?.placement?.width ?? 110,
      height: options?.placement?.height ?? 70,
      top: options?.placement?.top,
      left: options?.placement?.left,
      rotation: options?.placement?.rotation ?? 0,
    },
    oneClickMode: options?.oneClickMode ?? OneClickMode.Off,
    links: options?.links ?? [],
  }),

  // Called when data changes
  prepareData: (dimensionContext: DimensionContext, elementOptions: CanvasElementOptions<CanvasElementConfig>) => {
    const textConfig = elementOptions.config;

    const data: CanvasElementData = {
      text: textConfig?.text ? dimensionContext.getText(textConfig.text).value() : '',
      field: textConfig?.text?.field,
      align: textConfig?.align ?? Align.Center,
      valign: textConfig?.valign ?? VAlign.Middle,
      size: textConfig?.size,
    };

    if (textConfig?.color) {
      data.color = dimensionContext.getColor(textConfig.color).value();
    }

    const { background } = elementOptions;
    data.backgroundColor = background?.color ? dimensionContext.getColor(background.color).value() : defaultBgColor;
    data.backgroundImage = background?.image ? dimensionContext.getResource(background.image).value() : undefined;

    return data;
  },

  registerOptionsUI: (builder) => {
    const category = ['Valvehov'];
    builder
      .addCustomEditor({
        category,
        id: 'textSelector',
        path: 'config.text',
        name: 'Text',
        editor: TextDimensionEditor,
      })
      .addCustomEditor({
        category,
        id: 'config.color',
        path: 'config.color',
        name: 'Text color',
        editor: ColorDimensionEditor,
        settings: {},
        defaultValue: {},
      })
      .addRadio({
        category,
        path: 'config.align',
        name: 'Align text',
        settings: {
          options: [
            { value: Align.Left, label: 'Left' },
            { value: Align.Center, label: 'Center' },
            { value: Align.Right, label: 'Right' },
          ],
        },
        defaultValue: Align.Left,
      })
      .addRadio({
        category,
        path: 'config.valign',
        name: 'Vertical align',
        settings: {
          options: [
            { value: VAlign.Top, label: 'Top' },
            { value: VAlign.Middle, label: 'Middle' },
            { value: VAlign.Bottom, label: 'Bottom' },
          ],
        },
        defaultValue: VAlign.Middle,
      })
      .addNumberInput({
        category,
        path: 'config.size',
        name: 'Text size',
        settings: {
          placeholder: 'Auto',
        },
      });
  },
};

const getStyles = (theme: GrafanaTheme2, data: CanvasElementData | undefined) => {
  const textTop = data?.valign === VAlign.Middle ? '50%' : data?.valign === VAlign.Top ? '10%' : '90%';
  const textLeft = data?.align === Align.Center ? '50%' : data?.align === Align.Left ? '10%' : '90%';
  const textTransform = `translate(${data?.align === Align.Center ? '-50%' : data?.align === Align.Left ? '10%' : '-90%'}, ${
    data?.valign === VAlign.Middle ? '-50%' : data?.valign === VAlign.Top ? '10%' : '-90%'
  })`;

  return {
    container: css({
      height: '100%',
      width: '100%',
    }),
    text: css({
      position: 'absolute',
      top: textTop,
      left: textLeft,
      transform: textTransform,
      fontSize: `${data?.size}px`,
      color: data?.color,
    }),
  };
};

