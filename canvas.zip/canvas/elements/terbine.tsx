import { css } from '@emotion/css';
import { v4 as uuidv4 } from 'uuid';

import { GrafanaTheme2, OneClickMode } from '@grafana/data';
import { config } from 'app/core/config';
import { DimensionContext } from 'app/features/dimensions';
import { ColorDimensionEditor } from 'app/features/dimensions/editors/ColorDimensionEditor';
import { TextDimensionEditor } from 'app/features/dimensions/editors/TextDimensionEditor';

import {
  CanvasElementItem,
  CanvasElementProps,
  CanvasElementOptions,
  defaultBgColor,
  defaultTextColor,
} from '../element';
import { Align, CanvasElementConfig, CanvasElementData, VAlign } from '../types';

const Terbine = (props: CanvasElementProps<CanvasElementConfig, CanvasElementData>) => {
  const { data } = props;
  const styles = getStyles(config.theme2, data);

  // uuid needed to avoid id conflicts when multiple elements are rendered
  const uniqueId = uuidv4();

  return (
    <div className={styles.container}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="-0.5 -0.5 414 192"
        width="100%"
        height="100%"
        preserveAspectRatio="none"
      >
        <g>
        <path
                    d="M 406.3 5 L 406.79 95.57 L 406 185.19"
                    style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
                    strokeWidth={10}
                    strokeMiterlimit={10}
                    pointerEvents="stroke"
                   
                  />
        <path
                    d="M 4.3 5.59 L 4.79 96.21 L 4 185.78"
                    style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
                    strokeWidth={10}
                    strokeMiterlimit={10}
                    pointerEvents="stroke"
                    
                  />
         <rect
                    x={45}
                    y={7}
                    width={320}
                    height={175}
                    fill="none"
                    strokeWidth={10}
                    pointerEvents="all"
                    style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
                    />
         <path
                    d="M 149.1 98.18 L 261.43 98.18"
                    style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
                    strokeWidth={10}
                    strokeMiterlimit={10}
                    transform="rotate(305,205.26,98.18)"
                    pointerEvents="all"
                    
                    />
            <path
                    d="M 152.01 96.5 L 257.96 96.5"
                    style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
                    strokeWidth={10}
                    strokeMiterlimit={10}
                    transform="translate(204.98,0)scale(-1,1)translate(-204.98,0)rotate(-414,204.98,96.5)"
                    pointerEvents="all"
                   

                    />
             <path
                    d="M 213.66 78.75 C 201.58 82.35 188.54 78.01 181.02 67.9 C 173.5 57.78 173.11 44.04 180.04 33.51 C 186.97 22.98 199.74 17.9 212.01 20.81"
                    style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
                    fill="none"
                    strokeWidth={10}
                    strokeMiterlimit={10}
                    transform="rotate(90,205.1,50)"
                    pointerEvents="all"
                    
                    />
            <path
                    d="M 208.73 170.78 C 197.48 172.15 186.41 167.06 180.12 157.62 C 173.84 148.18 173.42 136 179.03 126.15 C 184.65 116.3 195.34 110.45 206.66 111.04"
                    style={{ stroke: data?.backgroundImage ? `url(#image-${uniqueId})` : data?.backgroundColor }}
                    fill="none"
                    strokeWidth={10}
                    strokeMiterlimit={10}
                    transform="rotate(-90,205.1,141)"
                    pointerEvents="all"
                    
                  />
        </g>
      </svg>
      <span className={styles.text}>{data?.text}</span>
    </div>
  );
};

export const terbineItem: CanvasElementItem = {
  id: 'terbine',
  name: 'Terbine',
  description: 'Terbine Flow Meter',

  display: Terbine,

  defaultSize: {
    width: 110,
    height: 70,
  },

  getNewOptions: (options) => ({
    ...options,
    background: {
      color: {
        fixed: defaultBgColor,
      },
    },
    config: {
      align: Align.Center,
      valign: VAlign.Middle,
      color: {
        fixed: defaultTextColor,
      },
    },
    placement: {
      width: options?.placement?.width ?? 110,
      height: options?.placement?.height ?? 70,
      top: options?.placement?.top,
      left: options?.placement?.left,
      rotation: options?.placement?.rotation ?? 0,
    },
    oneClickMode: options?.oneClickMode ?? OneClickMode.Off,
    links: options?.links ?? [],
  }),

  // Called when data changes
  prepareData: (dimensionContext: DimensionContext, elementOptions: CanvasElementOptions<CanvasElementConfig>) => {
    const textConfig = elementOptions.config;

    const data: CanvasElementData = {
      text: textConfig?.text ? dimensionContext.getText(textConfig.text).value() : '',
      field: textConfig?.text?.field,
      align: textConfig?.align ?? Align.Center,
      valign: textConfig?.valign ?? VAlign.Middle,
      size: textConfig?.size,
    };

    if (textConfig?.color) {
      data.color = dimensionContext.getColor(textConfig.color).value();
    }

    const { background } = elementOptions;
    data.backgroundColor = background?.color ? dimensionContext.getColor(background.color).value() : defaultBgColor;
    data.backgroundImage = background?.image ? dimensionContext.getResource(background.image).value() : undefined;

    return data;
  },

  registerOptionsUI: (builder) => {
    const category = ['Terbine'];
    builder
      .addCustomEditor({
        category,
        id: 'textSelector',
        path: 'config.text',
        name: 'Text',
        editor: TextDimensionEditor,
      })
      .addCustomEditor({
        category,
        id: 'config.color',
        path: 'config.color',
        name: 'Text color',
        editor: ColorDimensionEditor,
        settings: {},
        defaultValue: {},
      })
      .addRadio({
        category,
        path: 'config.align',
        name: 'Align text',
        settings: {
          options: [
            { value: Align.Left, label: 'Left' },
            { value: Align.Center, label: 'Center' },
            { value: Align.Right, label: 'Right' },
          ],
        },
        defaultValue: Align.Left,
      })
      .addRadio({
        category,
        path: 'config.valign',
        name: 'Vertical align',
        settings: {
          options: [
            { value: VAlign.Top, label: 'Top' },
            { value: VAlign.Middle, label: 'Middle' },
            { value: VAlign.Bottom, label: 'Bottom' },
          ],
        },
        defaultValue: VAlign.Middle,
      })
      .addNumberInput({
        category,
        path: 'config.size',
        name: 'Text size',
        settings: {
          placeholder: 'Auto',
        },
      });
  },
};

const getStyles = (theme: GrafanaTheme2, data: CanvasElementData | undefined) => {
  const textTop = data?.valign === VAlign.Middle ? '50%' : data?.valign === VAlign.Top ? '10%' : '90%';
  const textLeft = data?.align === Align.Center ? '50%' : data?.align === Align.Left ? '10%' : '90%';
  const textTransform = `translate(${data?.align === Align.Center ? '-50%' : data?.align === Align.Left ? '10%' : '-90%'}, ${
    data?.valign === VAlign.Middle ? '-50%' : data?.valign === VAlign.Top ? '10%' : '-90%'
  })`;

  return {
    container: css({
      height: '100%',
      width: '100%',
    }),
    text: css({
      position: 'absolute',
      top: textTop,
      left: textLeft,
      transform: textTransform,
      fontSize: `${data?.size}px`,
      color: data?.color,
    }),
  };
};

